package com.jdbc;

import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class AddUserGUI extends JFrame implements ActionListener {

    JTextField txtName, txtPhone;
    JComboBox<String> comboRole;
    JButton btnSave;

    public AddUserGUI() {
        setTitle("Library Management System - Add User");
        setSize(350, 300);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel l1 = new JLabel("Add New User");
        l1.setBounds(110, 10, 150, 25);
        add(l1);

        JLabel l2 = new JLabel("Name:");
        l2.setBounds(30, 50, 100, 25);
        add(l2);

        txtName = new JTextField();
        txtName.setBounds(140, 50, 150, 25);
        add(txtName);

        JLabel l3 = new JLabel("Phone:");
        l3.setBounds(30, 90, 100, 25);
        add(l3);

        txtPhone = new JTextField();
        txtPhone.setBounds(140, 90, 150, 25);
        add(txtPhone);

        JLabel l4 = new JLabel("Role:");
        l4.setBounds(30, 130, 100, 25);
        add(l4);

        comboRole = new JComboBox<>(new String[]{"student", "admin", "librarian"});
        comboRole.setBounds(140, 130, 150, 25);
        add(comboRole);

        btnSave = new JButton("Save User");
        btnSave.setBounds(110, 180, 120, 30);
        add(btnSave);

        btnSave.addActionListener(this);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        try {
            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO users(user_name, user_phone_no, role) VALUES (?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, txtName.getText());
            ps.setString(2, txtPhone.getText());
            ps.setString(3, comboRole.getSelectedItem().toString());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "User Added Successfully!");

            txtName.setText("");
            txtPhone.setText("");

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new AddUserGUI();
    }
}

