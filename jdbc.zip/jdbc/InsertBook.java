package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class InsertBook {
    public static void main(String[] args) {

        try {
            Connection con = DBConnection.getConnection();
            
            
                  
            
            String sql = "INSERT INTO books(title,author,publisher,category,price,quantity,rack_no) VALUES (?,?,?,?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, "Python Programming");
            ps.setString(2, "Guido");
            ps.setString(3, "O'Reilly");
            ps.setString(4, "Programming");
            ps.setDouble(5, 550);
            ps.setInt(6, 20);
            ps.setString(7, "R2-B");

            ps.executeUpdate();
            System.out.println("Book Inserted Successfully");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
