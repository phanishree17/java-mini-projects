package com.jdbc;

import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class IssueBookGUI extends JFrame implements ActionListener {

    JTextField txtBookId, txtUserId, txtIssueDate, txtReturnDate, txtName, txtPhone;
    JButton btnIssue;

    public IssueBookGUI() {

        setTitle("Library Management System - Issue Book");
        setSize(400, 400);
        setLayout(null);
        setLocationRelativeTo(null);

        JLabel l1 = new JLabel("Issue Book Form");
        l1.setBounds(130, 10, 200, 25);
        add(l1);

        addLabel("Book ID:", 50);
        txtBookId = addTextField(50);

        addLabel("User ID:", 90);
        txtUserId = addTextField(90);

        addLabel("Issue Date (YYYY-MM-DD):", 130);
        txtIssueDate = addTextField(130);

        addLabel("Return Date (YYYY-MM-DD):", 170);
        txtReturnDate = addTextField(170);

        addLabel("User Name:", 210);
        txtName = addTextField(210);

        addLabel("Phone No:", 250);
        txtPhone = addTextField(250);

        btnIssue = new JButton("ISSUE BOOK");
        btnIssue.setBounds(130, 300, 130, 30);
        add(btnIssue);

        btnIssue.addActionListener(this);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    void addLabel(String text, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(30, y, 200, 25);
        add(lbl);
    }

    JTextField addTextField(int y) {
        JTextField tf = new JTextField();
        tf.setBounds(200, y, 150, 25);
        add(tf);
        return tf;
    }

    public void actionPerformed(ActionEvent e) {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO issued_book(book_id, user_id, issued_date, return_date, issued_user_name, user_phone_no) VALUES (?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, Integer.parseInt(txtBookId.getText()));
            ps.setInt(2, Integer.parseInt(txtUserId.getText()));
            ps.setDate(3, Date.valueOf(txtIssueDate.getText()));
            ps.setDate(4, Date.valueOf(txtReturnDate.getText()));
            ps.setString(5, txtName.getText());
            ps.setString(6, txtPhone.getText());

            ps.executeUpdate();

            // Reduce book quantity automatically
            String updateQty = "UPDATE books SET quantity = quantity - 1 WHERE book_id = ?";
            PreparedStatement ps2 = con.prepareStatement(updateQty);
            ps2.setInt(1, Integer.parseInt(txtBookId.getText()));
            ps2.executeUpdate();

            JOptionPane.showMessageDialog(this, "Book Issued Successfully!");

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new IssueBookGUI();
    }
}
