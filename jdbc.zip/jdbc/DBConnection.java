package com.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    public static Connection getConnection() {
        Connection con = null;

        try {
            // Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Change db name, username, password if needed
            String url = "jdbc:mysql://localhost:3306/library_db";
            String user = "root";
            String password = ""; // XAMPP default is empty

            con = DriverManager.getConnection(url, user, password);
            System.out.println("✅ Database Connected Successfully");

        } catch (Exception e) {
            System.out.println("❌ Database Connection Failed");
            e.printStackTrace();
        }

        return con;
    }
}

