package com.jdbc;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;

public class IssueBook {
    public static void main(String[] args) {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO issued_book(book_id, user_id, issued_date, return_date, issued_user_name, user_phone_no) VALUES (?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, 1); // book_id from books table
            ps.setInt(2, 1); // user_id from users table
            ps.setDate(3, Date.valueOf("2026-02-04"));
            ps.setDate(4, Date.valueOf("2026-02-10"));
            ps.setString(5, "Ramesh");
            ps.setString(6, "9876543210");

            ps.executeUpdate();
            System.out.println("Book Issued Successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
