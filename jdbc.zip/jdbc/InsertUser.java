package com.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class InsertUser {
    public static void main(String[] args) {

        try {
            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO users(user_name, user_phone_no, role) VALUES (?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, "Suresh");
            ps.setString(2, "9876543210");
            ps.setString(3, "student");

            ps.executeUpdate();
            System.out.println("User Inserted Successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
