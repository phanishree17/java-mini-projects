package com.jdbc;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AddBookGUI extends JFrame implements ActionListener {

    JTextField txtTitle, txtAuthor, txtPublisher, txtCategory, txtPrice, txtQuantity, txtRack;
    JButton btnSave;

    public AddBookGUI() {
        setTitle("Library Management System - Add Book");
        setSize(400, 450);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel l1 = new JLabel("Add New Book");
        l1.setFont(new Font("Arial", Font.BOLD, 18));
        l1.setBounds(120, 10, 200, 30);
        add(l1);

        addLabel("Title:", 50);
        txtTitle = addTextField(50);

        addLabel("Author:", 90);
        txtAuthor = addTextField(90);

        addLabel("Publisher:", 130);
        txtPublisher = addTextField(130);

        addLabel("Category:", 170);
        txtCategory = addTextField(170);

        addLabel("Price:", 210);
        txtPrice = addTextField(210);

        addLabel("Quantity:", 250);
        txtQuantity = addTextField(250);

        addLabel("Rack No:", 290);
        txtRack = addTextField(290);

        btnSave = new JButton("SAVE BOOK");
        btnSave.setBounds(130, 340, 120, 30);
        add(btnSave);

        btnSave.addActionListener(this);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    void addLabel(String text, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setBounds(30, y, 100, 25);
        add(lbl);
    }

    JTextField addTextField(int y) {
        JTextField tf = new JTextField();
        tf.setBounds(140, y, 200, 25);
        add(tf);
        return tf;
    }

    public void actionPerformed(ActionEvent e) {
        try {
            Connection con = DBConnection.getConnection();

            String sql = "INSERT INTO books(title,author,publisher,category,price,quantity,rack_no) VALUES (?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, txtTitle.getText());
            ps.setString(2, txtAuthor.getText());
            ps.setString(3, txtPublisher.getText());
            ps.setString(4, txtCategory.getText());
            ps.setDouble(5, Double.parseDouble(txtPrice.getText()));
            ps.setInt(6, Integer.parseInt(txtQuantity.getText()));
            ps.setString(7, txtRack.getText());

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Book Added Successfully!");

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new AddBookGUI();
    }
}
